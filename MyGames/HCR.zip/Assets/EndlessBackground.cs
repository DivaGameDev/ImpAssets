using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EndlessBackground : MonoBehaviour
{
    public void OnBecameInvisible()
    {
        transform.position = new Vector2(transform.position.x + 327f, 5);
    }
}
