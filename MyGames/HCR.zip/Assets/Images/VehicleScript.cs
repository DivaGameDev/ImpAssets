using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class VechcleScript : MonoBehaviour
{
    public WheelJoint2D front, back;
    bool ApplySpeed;
    float speed;
    JointMotor2D frontM, backM;
    void Update()
    {
        speed = Mathf.Clamp(speed,1, 1000);
        if (ApplySpeed)
        {  if(speed<1000)
                 speed+=100*Time.deltaTime;
            frontM = front.motor;
            backM = back.motor;
            frontM.motorSpeed = speed;
            backM.motorSpeed = speed;
            front.motor = frontM;
            back.motor = backM;
        }
        else
        {
         if(speed>0)
                speed-=100*Time.deltaTime;
            frontM = front.motor;
            backM = back.motor;
            frontM.motorSpeed = speed;
            backM.motorSpeed = speed;
            front.motor = frontM;
            back.motor = backM;
        }
     
    }
    public void GasDown()
    {
        ApplySpeed = true;
      
    }
    public void GasUp()
    {
        ApplySpeed = false;
       
    }
}
