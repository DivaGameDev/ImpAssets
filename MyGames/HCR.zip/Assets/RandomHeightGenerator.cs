using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.U2D;

public class RandomHeightGenerator : MonoBehaviour
{
    public SpriteShapeController roadBit;
    public GameObject cam;

    private void Start()
    {
        GenereateRandomHeight();
    }
    void GenereateRandomHeight()
    {
        for(int i=2;i<=5;i++)
        {
            Vector2 height = roadBit.spline.GetPosition(i);
            height.y = Random.Range(-5.0f, 5.0f);
            roadBit.spline.SetPosition(i, height);
        }
    }
    private void Update()
    {
        if(cam.transform.position.x >transform.position.x+99)
        {
            transform.position = new Vector2(transform.position.x + 99 + 99, 0);
            GetComponent<RandomHeightGenerator>().GenereateRandomHeight();
        }
    }
}
