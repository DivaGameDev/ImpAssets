﻿namespace Gpm.Common
{
    public static class GpmCommon
    {
        public const string VERSION = "2.3.1";
        public static bool DebugLogEnabled { get; set; }
    }
}