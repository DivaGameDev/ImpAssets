﻿namespace Gpm.Common.Indicator.Internal
{
    public static class Launching
    {
        public const string URI = "https://launching.api.nhncloudservice.com/launching";
        public const string VERSION = "v3.0";
        public const string APP_KEY = "Wk5YcnVXWUlOaXRJT0NMcw==";
    }
}