#if CSHARP_7_3_OR_NEWER

namespace Gpm.Common.ThirdParty.SharpCompress.Common
{
    public enum ArchiveType
    {
        Rar,
        Zip,
        Tar,
        SevenZip,
        GZip
    }
}

#endif