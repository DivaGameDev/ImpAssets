#if CSHARP_7_3_OR_NEWER

namespace Gpm.Common.ThirdParty.SharpCompress.Common.SevenZip
{
    internal class CBindPair
    {
        internal int _inIndex;
        internal int _outIndex;
    }
}

#endif