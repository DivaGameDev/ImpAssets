#if CSHARP_7_3_OR_NEWER

namespace Gpm.Common.ThirdParty.SharpCompress.Common.Zip
{
    internal enum WinzipAesKeySize
    {
        KeySize128 = 1,
        KeySize192 = 2,
        KeySize256 = 3
    }
}

#endif