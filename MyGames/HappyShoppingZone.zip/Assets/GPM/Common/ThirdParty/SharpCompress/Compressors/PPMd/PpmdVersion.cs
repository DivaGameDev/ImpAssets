#if CSHARP_7_3_OR_NEWER

namespace Gpm.Common.ThirdParty.SharpCompress.Compressors.PPMd
{
    public enum PpmdVersion
    {
        H,
        H7Z,
        I1
    }
}

#endif