#if CSHARP_7_3_OR_NEWER

namespace Gpm.Common.ThirdParty.SharpCompress.Compressors.Rar.UnpackV1.PPM
{
    internal enum BlockTypes
    {
        BLOCK_LZ = 0,
        BLOCK_PPM = 1
    }
}

#endif