#if CSHARP_7_3_OR_NEWER

using System;

namespace Gpm.Common.ThirdParty.SharpCompress.Compressors.Xz
{
    public class XZIndexMarkerReachedException : Exception
    {
    }
}


#endif