#if CSHARP_7_3_OR_NEWER

namespace Gpm.Common.ThirdParty.SharpCompress.Crypto
{
    public interface ICipherParameters
    {
    }
}

#endif