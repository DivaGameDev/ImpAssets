#if CSHARP_7_3_OR_NEWER

namespace Gpm.Common.ThirdParty.SharpCompress.IO
{
    internal enum StreamingMode
    {
        Streaming,
        Seekable
    }
}

#endif