﻿namespace Gpm.Communicator
{
    public class GpmCommunicatorCallback
    {
        public delegate void CommunicatorCallback(GpmCommunicatorVO.Message message);
    }
}