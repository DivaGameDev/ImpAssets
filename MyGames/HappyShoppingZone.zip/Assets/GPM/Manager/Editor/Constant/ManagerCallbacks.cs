namespace Gpm.Manager.Constant
{
    internal delegate void ErrorCallback(ManagerError error);
}