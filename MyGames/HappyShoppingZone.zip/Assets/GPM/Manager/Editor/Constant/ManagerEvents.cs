﻿namespace Gpm.Manager.Constant
{
    internal static class ManagerEvents
    {
        public const string IMAGE_SELECT = "ImageView";
        public const string CHANGE_SERVICE = "ChangeService";
        public const string INFO_RESET = "InfoReset";
    }
}
