﻿using System;

namespace Gpm.Manager.Constant
{
    [Serializable]
    internal class UiRefreshInfo
    {
        public string lastServiceName;
    }
}
