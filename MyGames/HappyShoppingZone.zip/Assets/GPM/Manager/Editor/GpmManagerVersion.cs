﻿namespace Gpm.Manager
{
    public static class GpmManagerVersion
    {
        public const string VERSION = "2.2.5";
    }
}